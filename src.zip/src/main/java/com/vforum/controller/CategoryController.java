package com.vforum.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;
import com.vforum.model.Questions;
import com.vforum.service.AnswerService;
import com.vforum.service.QuestionService;

@Controller
@SessionAttributes("employeeId")
public class CategoryController {
		

	private Logger log=Logger.getLogger(this.getClass());
		@Autowired
		private AnswerService answerService;
		@Autowired
		private QuestionService questionService;
	   
	    @RequestMapping(value = "/selectedCategory", method = RequestMethod.GET)
	    public ModelAndView selectedCategory(ModelAndView model,@RequestParam(value="categoryId") Integer categoryId,HttpSession session) {
	       
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is CategoryController selectCategory method");
			         model.addObject("categoryId",categoryId);
			         List<Questions> allQuestions=questionService.getAllQuestionByCategory(categoryId);
				     model.addObject("allQuestions",allQuestions);
				     List<Answers> allAnswers=answerService.getAllAnswers();
				     model.addObject("allAnswers",allAnswers);
			         model.setViewName("categoryDisplay");
	    		}
	        
	    	} catch (Exception e) {
				log.error("Error is in CategoryController selectCategory method " + e);
			}
	    	return model;
	    }
}