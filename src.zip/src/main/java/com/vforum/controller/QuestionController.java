package com.vforum.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Questions;
import com.vforum.service.AnswerService;
import com.vforum.service.CategoryService;
import com.vforum.service.EmployeeService;
import com.vforum.service.QuestionService;
@Controller
public class QuestionController {
	Logger log = Logger.getLogger(this.getClass());
	@Autowired
    private EmployeeService employeeService;
    @Autowired
    private QuestionService questionService;
    @Autowired
    private AnswerService answerService;
    @Autowired
    private CategoryService categoryService;
	 @RequestMapping("/addQuestion")    
	    public ModelAndView addQuestion(ModelAndView model,HttpSession session,@RequestParam(value="cId") Integer categoryId){   
		   
		 	try {
		 		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController postQuestion method Log");
			    	Questions question=new Questions();
			    	long milli=System.currentTimeMillis();
					Date currentDate=new Date(milli);
			    	question.setDate(currentDate);
			        question.setEmployee(employeeService.getEmployee(employeeId));
			        question.setCategory(categoryService.getCategoryById(categoryId));
			    	model.addObject("question", question);
			        model.setViewName("Question");
	    		}  
			} catch (Exception e) {
				log.error("Error is in QuestionController postQuestion method Log " + e);
			}
	    	return model;
	    }
	 
	    @RequestMapping(value = "/addQuestionProcess", method = RequestMethod.POST)
	    public String addQuestionProcess(@ModelAttribute Questions question,HttpSession session) {
	    	
	    	String url=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController addQuestion method Log");
					questionService.addQuestion(question);
					url="redirect:viewMyQuestion";

	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController addQuestion method Log" + e);
			}
	    	return url;
	       
	    }
	 
	    @RequestMapping(value = "/editQuestion", method = RequestMethod.GET)
	    public ModelAndView editQuestion(@RequestParam(value="qid") Integer questionId,HttpSession session) {
	    	ModelAndView model=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController editQuestion method Log");
			        Questions question = questionService.getQuestion(questionId);
			        model = new ModelAndView();
			        model.addObject("question", question);
			        System.out.println("edit ques"+question.getQuestionDescription());
			        model.setViewName("editQuestion");
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController editQuestion method Log " + e);
		}
	    	return model;
	    }
	   
	    @RequestMapping(value = "/editQuestionProcess", method = RequestMethod.POST)
	    public String editQuestionProcess(@ModelAttribute Questions question,HttpSession session) {
	     	
	     	String url=null;
	    	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController editQuestionProcess method Log");
					System.out.println("date"+question.getDate());
					System.out.println("ques desc  "+question.getQuestionDescription());
					System.out.println("questionid   "+ question.getQuestionId());
					questionService.editQuestion(question);
					url="redirect:viewMyQuestion";
		        }
	    	} catch (Exception e) {
				log.error("Error is in QuestionController editQuestionProcess method Log " + e);
			}
	    	return url;
	    }
	    
	
	    @RequestMapping(value = "/deleteQuestion", method = RequestMethod.GET)
	    public String deleteQuestion(@RequestParam(value="qid") Integer questionId,HttpSession session) {
	     
	    	String url=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController deleteQuestion method Log");
			        Questions question = questionService.getQuestion(questionId);
			        List<Answers> answerList=answerService.getAnswersByQuestionId(questionId);
			        for(Answers ans:answerList) {
			        	answerService.deleteAnswer(ans);
			        }
			        questionService.deleteQuestion(question);
			        url="redirect:viewMyQuestion";
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController deleteQuestion method Log" + e);
			}
	    	return url;
	    }
	    @RequestMapping(value = "/viewMyQuestion", method = RequestMethod.GET)
	    public ModelAndView viewMyQuestion(HttpSession session) {
	    	ModelAndView model=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
				log.info("This is QuestionController viewQuestion method Log");
				model = new ModelAndView();
				Employee employee=employeeService.getEmployee(employeeId);
			    model.addObject("employee",employee);
				List<Questions> allQuestions=questionService.getAllQuestionByEmployee(employeeId);
				model.addObject("allQuestions",allQuestions);
				model.setViewName("MyQuestions");
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController viewQuestion method Log" + e);
			}
	    	return model;
	    }
	   
}
