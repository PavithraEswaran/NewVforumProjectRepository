package com.vforum.dao;

import com.vforum.model.Category;

public interface CategoryDao {
		
	public Category getCategoryById(int categoryId);
	
}