package com.vforum.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;

import com.vforum.service.AnswerService;
import com.vforum.service.EmployeeService;
import com.vforum.service.QuestionService;

@Controller
public class AnswerController {

	
		Logger log = Logger.getLogger(this.getClass());
		@Autowired
	    private EmployeeService employeeService;
	    @Autowired
	    private AnswerService answerService;
	    @Autowired
	    private QuestionService questionService;
	    
	    @RequestMapping(value ="/addAnswer", method = RequestMethod.GET)    
	    public ModelAndView addAnswer(ModelAndView model,HttpSession session,@RequestParam(value="qid") Integer questionId){ 
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is in AnswerController postAnswer method ");
			    	Answers answer=new Answers();
			    	long milli=System.currentTimeMillis();
					Date currentDate=new Date(milli);
			    	answer.setDate(currentDate);
			    	answer.setQuestion(questionService.getQuestion(questionId));
			        answer.setEmployee(employeeService.getEmployee(employeeId));
			    	model.addObject("answer", answer);
			        model.setViewName("Answer");
	    		    				}
		 		} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method  " + e);
		 		}
	    	return model;
	    }
	 
	    @RequestMapping(value = "/addAnswerProcess", method = RequestMethod.POST)
	    public String addAnswerProcess(@ModelAttribute Answers answer,HttpSession session) {
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					
					log.info("This is AnswerController addAnswer method ");
			    	answerService.addAnswer(answer);
			    	url="redirect:homePage";
//			        m=new ModelAndView();
//			       
//			        Employee employee=employeeService.getEmployee(employeeId);
//				    m.addObject("employee",employee);
//			        List<Questions> allQuestions=questionService.getAllQuestions();
//			        m.addObject("allQuestions",allQuestions);
//			        List<Answers> allAnswers=answerService.getAllAnswers();
//			        m.addObject("allAnswers",allAnswers);
//			        m.setViewName("home");
	    		}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController addAnswer method " + e);
			}
	    	return url;
	       
	    }
	    @RequestMapping(value = "/editAnswer", method = RequestMethod.GET)
	    public ModelAndView editAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	    	ModelAndView model =null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController editAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        model = new ModelAndView();
			        model.addObject("answer", answer);
			        model.setViewName("editAnswer");
	    		}
		        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController editAnswer method " + e);
			}
	    	return model;
	    }
	   
	    @RequestMapping(value = "/editAnswerProcess", method = RequestMethod.POST)
	    public String editAnswerProcess(@ModelAttribute Answers answer,HttpSession session) {
	    	
	    	//ModelAndView model=null;
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController postAnswer method ");
					answerService.editAnswer(answer);
					url="redirect:homePage";
//			        model = new ModelAndView();
//			        Employee employee=employeeService.getEmployee(employeeId);
//				    model.addObject("employee",employee);
//			        List<Questions> allQuestions=questionService.getAllQuestions();
//			        model.addObject("allQuestions",allQuestions);
//			        List<Answers> allAnswers=answerService.getAllAnswers();
//			        model.addObject("allAnswers",allAnswers);
//			        model.setViewName("home");
	    		}
	       
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	 return url;
	    }
	    @RequestMapping(value = "/deleteAnswer", method = RequestMethod.GET)
	    public String deleteAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	      //ModelAndView model=null;
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController postAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        answerService.deleteAnswer(answer);
			        url="redirect:homePage";
//			        model = new ModelAndView();
//			        Employee employee=employeeService.getEmployee(employeeId);
//				    model.addObject("employee",employee);
//			        List<Questions> allQuestions=questionService.getAllQuestions();
//			        model.addObject("allQuestions",allQuestions);
//			        List<Answers> allAnswers=answerService.getAllAnswers();
//			        model.addObject("allAnswers",allAnswers);
//			        model.setViewName("home");
	    		}
			        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	return url;
	    }
	    @RequestMapping(value = "/viewAnswer", method = RequestMethod.GET)
	    public ModelAndView viewAnswer(HttpSession session) {
	    	ModelAndView model=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController viewAnswer method ");
				    model = new ModelAndView();
			     	List<Answers> allAnswers=answerService.getAllAnswers();
			        model.addObject("allAnswers",allAnswers);
			        model.setViewName("MyAnswers");
	    							}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController viewAnswer method " + e);
			}
	        return model;
	    }
	    

}